#clasee admin
from entidades_usuario import Usuario_entidad
class Admin(Usuario_entidad):

    def listar_usuarios(self):
        pass

    def eliminar_usuarios(self):
        pass

